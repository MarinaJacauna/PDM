package com.example.alcides.exercicioaula7.model;

import java.util.*;

public class ArrayListAlunoDAO implements AlunoDAO {  // Data Access Object, DAO, regras de acesso a banco de dados
	public static List<Aluno> alunos = new ArrayList<Aluno>();
	
	public ArrayListAlunoDAO() {
	}
	
	public boolean insert(Aluno aluno) {
		System.out.print(aluno.getRgm());
		try{
			if (select(aluno.getRgm())==null){
				alunos.add(aluno);
				return true;
			}else{
				return false;
			}
		}catch (Exception e){
			return false;
		}
	}
	
	public boolean delete(Aluno aluno) {
		if (alunos.contains(aluno)){
			alunos.remove(aluno);
			return true;
		}
		return false;
	}
	
	public boolean update(Aluno aluno) {
		try{
			alunos.set(alunos.indexOf(aluno),aluno);
			return true;
		}catch (Exception e){
			return false;
		}
	}
	
	public Aluno select(String rgm) {
		for (int i=0;i< alunos.size();i++) {
			if (alunos.get(i).getRgm().equals((rgm))){
				return alunos.get(i);
			}
		}
		return null;
	}
	
	public List<Aluno> selectAll() {
		return alunos;
	}
}
